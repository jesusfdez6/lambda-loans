module.exports = {
    NAME_LAMBDA : "LOANS",
}